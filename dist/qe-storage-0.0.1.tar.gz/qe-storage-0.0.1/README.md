# Support basic operations (crud, query) for cloud-MongoDB and embedded local-TinyDB

## \* Note: Query need follow specific database format

### https://tinydb.readthedocs.io/en/latest/usage.html#queries

### https://www.mongodb.com/docs/manual/tutorial/query-documents/
